# Natus Vincere Academy - Windows 11 Installation

## Quick Start

1. Download the application package
2. Extract the ZIP file to your preferred location (e.g., C:\Programs\NatusVincere\)
3. Double-click "start.bat" to launch the application
4. Create a desktop shortcut if desired

## System Requirements

- Windows 11 (64-bit)
- Node.js runtime (automatically included)
- 4GB RAM minimum
- 500MB free disk space

## Features

- Complete football club management system
- Offline functionality with automatic sync
- Secure data storage
- Multi-language support (Portuguese/English)
- Integration with web and mobile platforms

## Troubleshooting

**If the application doesn't start:**
1. Ensure Windows 11 is updated
2. Run start.bat as Administrator
3. Check Windows Defender permissions

**For sync issues:**
1. Verify internet connection
2. Check firewall settings
3. Ensure web application is accessible

## Support

Email: support@natusvincere.academy
Documentation: README.md
