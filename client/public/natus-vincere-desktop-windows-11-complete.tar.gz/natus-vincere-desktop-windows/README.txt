NATUS VINCERE ACADEMY - DESKTOP APPLICATION FOR WINDOWS 11
===========================================================

INSTALLATION INSTRUCTIONS:
1. Extract this ZIP file to your desired location (e.g., C:\Programs\NatusVincere\)
2. Double-click "start.bat" to launch the application
3. The first run will automatically install dependencies

SYSTEM REQUIREMENTS:
- Windows 11 (64-bit)
- 4GB RAM minimum
- 500MB free disk space
- Internet connection for data sync

FEATURES:
- Complete football club management
- Offline functionality with auto-sync
- Native Windows 11 integration
- Secure encrypted data storage
- Multi-language support

SUPPORT:
Email: support@natusvincere.academy

VERSION: 1.0.0
BUILD DATE: December 2024