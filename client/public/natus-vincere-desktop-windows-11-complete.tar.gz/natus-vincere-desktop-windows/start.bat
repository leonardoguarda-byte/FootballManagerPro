@echo off
title Natus Vincere Academy - Desktop Application
echo.
echo ============================================
echo   Natus Vincere Academy Desktop App
echo ============================================
echo.
echo Starting the application...
echo.

REM Check if Node.js is installed
node --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js is not installed or not in PATH
    echo Please install Node.js from https://nodejs.org/
    echo.
    pause
    exit /b 1
)

REM Check if Electron is installed
if not exist node_modules\electron (
    echo Installing dependencies...
    call npm install --silent
    if errorlevel 1 (
        echo ERROR: Failed to install dependencies
        pause
        exit /b 1
    )
)

REM Start the Electron application
echo Launching Natus Vincere Academy...
electron .

REM If we get here, the app has closed
echo.
echo Application closed.
pause