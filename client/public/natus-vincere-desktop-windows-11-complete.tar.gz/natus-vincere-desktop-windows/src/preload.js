const { contextBridge, ipcRenderer } = require('electron');

// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object
contextBridge.exposeInMainWorld('electronAPI', {
  // App settings
  getAppSettings: () => ipcRenderer.invoke('get-app-settings'),
  setAppSetting: (key, value) => ipcRenderer.invoke('set-app-setting', key, value),
  
  // Authentication
  showAuthWindow: () => ipcRenderer.invoke('show-auth-window'),
  closeAuthWindow: () => ipcRenderer.invoke('close-auth-window'),
  
  // Network
  checkServerConnection: () => ipcRenderer.invoke('check-server-connection'),
  
  // Notifications
  showNotification: (title, body) => ipcRenderer.invoke('show-notification', title, body),
  
  // Navigation
  onNavigate: (callback) => ipcRenderer.on('navigate-to', callback),
  removeNavigateListener: () => ipcRenderer.removeAllListeners('navigate-to'),
  
  // Platform info
  platform: process.platform,
  
  // App info
  getVersion: () => process.env.npm_package_version || '1.0.0'
});

// Listen for navigation events from main process
window.addEventListener('DOMContentLoaded', () => {
  // Add desktop-specific styling
  document.body.classList.add('desktop-app');
  
  // Handle authentication state changes
  window.addEventListener('storage', (e) => {
    if (e.key === 'auth-state' && e.newValue === 'logged-out') {
      ipcRenderer.invoke('show-auth-window');
    }
  });
});