const { app, BrowserWindow, Menu, ipcMain, dialog, shell } = require('electron');
const { autoUpdater } = require('electron-updater');
const Store = require('electron-store');
const path = require('path');
const fetch = require('node-fetch');

// Configure store for app settings
const store = new Store({
  defaults: {
    serverUrl: 'https://localhost:5000',
    windowBounds: { width: 1400, height: 900 },
    offlineMode: false,
    syncInterval: 30000, // 30 seconds
    theme: 'light'
  }
});

let mainWindow;
let authWindow;

function createMainWindow() {
  const { width, height } = store.get('windowBounds');
  
  mainWindow = new BrowserWindow({
    width,
    height,
    minWidth: 1200,
    minHeight: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      enableRemoteModule: false,
      preload: path.join(__dirname, 'preload.js')
    },
    icon: path.join(__dirname, '../assets/icon.ico'),
    title: 'Natus Vincere Academy',
    show: false,
    titleBarStyle: 'default'
  });

  // Load the web application
  const serverUrl = store.get('serverUrl');
  mainWindow.loadURL(serverUrl);

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    
    // Check for updates
    if (!process.env.NODE_ENV || process.env.NODE_ENV === 'production') {
      autoUpdater.checkForUpdatesAndNotify();
    }
  });

  // Save window bounds when closed
  mainWindow.on('close', () => {
    store.set('windowBounds', mainWindow.getBounds());
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // Handle external links
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  // Development tools
  if (process.env.NODE_ENV === 'development') {
    mainWindow.webContents.openDevTools();
  }
}

function createAuthWindow() {
  authWindow = new BrowserWindow({
    width: 500,
    height: 700,
    parent: mainWindow,
    modal: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    title: 'Autenticação - Natus Vincere Academy'
  });

  const serverUrl = store.get('serverUrl');
  authWindow.loadURL(`${serverUrl}/api/login`);

  authWindow.on('closed', () => {
    authWindow = null;
  });
}

function createMenu() {
  const template = [
    {
      label: 'Arquivo',
      submenu: [
        {
          label: 'Configurações',
          click: () => {
            mainWindow.webContents.send('navigate-to', '/settings');
          }
        },
        { type: 'separator' },
        {
          label: 'Sair',
          accelerator: 'CmdOrCtrl+Q',
          click: () => {
            app.quit();
          }
        }
      ]
    },
    {
      label: 'Editar',
      submenu: [
        { role: 'undo', label: 'Desfazer' },
        { role: 'redo', label: 'Refazer' },
        { type: 'separator' },
        { role: 'cut', label: 'Recortar' },
        { role: 'copy', label: 'Copiar' },
        { role: 'paste', label: 'Colar' },
        { role: 'selectall', label: 'Selecionar Tudo' }
      ]
    },
    {
      label: 'Visualizar',
      submenu: [
        { role: 'reload', label: 'Recarregar' },
        { role: 'forceReload', label: 'Forçar Recarregamento' },
        { role: 'toggleDevTools', label: 'Ferramentas do Desenvolvedor' },
        { type: 'separator' },
        { role: 'resetZoom', label: 'Zoom Real' },
        { role: 'zoomIn', label: 'Aumentar Zoom' },
        { role: 'zoomOut', label: 'Diminuir Zoom' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'Tela Cheia' }
      ]
    },
    {
      label: 'Academia',
      submenu: [
        {
          label: 'Dashboard',
          click: () => {
            mainWindow.webContents.send('navigate-to', '/');
          }
        },
        {
          label: 'Atletas',
          click: () => {
            mainWindow.webContents.send('navigate-to', '/athletes');
          }
        },
        {
          label: 'Equipes',
          click: () => {
            mainWindow.webContents.send('navigate-to', '/teams');
          }
        },
        {
          label: 'Treinos',
          click: () => {
            mainWindow.webContents.send('navigate-to', '/training');
          }
        },
        { type: 'separator' },
        {
          label: 'Sincronização Offline',
          click: () => {
            mainWindow.webContents.send('navigate-to', '/offline-test');
          }
        }
      ]
    },
    {
      label: 'Ajuda',
      submenu: [
        {
          label: 'Sobre',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'Sobre',
              message: 'Natus Vincere Academy',
              detail: 'Sistema de Gestão de Academia de Futebol\nVersão 1.0.0\n\nDesenvolvido para Windows 11',
              buttons: ['OK']
            });
          }
        },
        {
          label: 'Verificar Atualizações',
          click: () => {
            autoUpdater.checkForUpdatesAndNotify();
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

// App event handlers
app.whenReady().then(() => {
  createMainWindow();
  createMenu();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// IPC handlers
ipcMain.handle('get-app-settings', () => {
  return store.store;
});

ipcMain.handle('set-app-setting', (event, key, value) => {
  store.set(key, value);
  return true;
});

ipcMain.handle('show-auth-window', () => {
  createAuthWindow();
});

ipcMain.handle('close-auth-window', () => {
  if (authWindow) {
    authWindow.close();
  }
});

ipcMain.handle('check-server-connection', async () => {
  try {
    const serverUrl = store.get('serverUrl');
    const response = await fetch(`${serverUrl}/api/health`, {
      method: 'GET',
      timeout: 5000
    });
    return response.ok;
  } catch (error) {
    return false;
  }
});

ipcMain.handle('show-notification', (event, title, body) => {
  new Notification(title, { body }).show();
});

// Auto-updater events
autoUpdater.on('checking-for-update', () => {
  console.log('Checking for update...');
});

autoUpdater.on('update-available', (info) => {
  console.log('Update available.');
});

autoUpdater.on('update-not-available', (info) => {
  console.log('Update not available.');
});

autoUpdater.on('error', (err) => {
  console.log('Error in auto-updater. ' + err);
});

autoUpdater.on('download-progress', (progressObj) => {
  let log_message = "Download speed: " + progressObj.bytesPerSecond;
  log_message = log_message + ' - Downloaded ' + progressObj.percent + '%';
  log_message = log_message + ' (' + progressObj.transferred + "/" + progressObj.total + ')';
  console.log(log_message);
});

autoUpdater.on('update-downloaded', (info) => {
  console.log('Update downloaded');
  autoUpdater.quitAndInstall();
});

// Handle protocol for deep linking
app.setAsDefaultProtocolClient('natusvincere');

// Security: Prevent new window creation
app.on('web-contents-created', (event, contents) => {
  contents.on('new-window', (navigationEvent, navigationURL) => {
    navigationEvent.preventDefault();
    shell.openExternal(navigationURL);
  });
});