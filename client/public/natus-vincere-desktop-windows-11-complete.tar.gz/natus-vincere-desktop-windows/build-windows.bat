
@echo off
echo Building Natus Vincere Academy Desktop Application...
echo.

echo [1/4] Installing dependencies...
call npm install --silent

echo [2/4] Creating application bundle...
mkdir dist 2>nul
mkdir dist\win-app 2>nul

echo [3/4] Copying application files...
xcopy /E /I /Q src dist\win-app\src\
xcopy /E /I /Q assets dist\win-app\assets\
xcopy /Q package.json dist\win-app\
xcopy /Q *.md dist\win-app\

echo [4/4] Creating launcher...
echo @echo off > dist\win-app\start.bat
echo echo Starting Natus Vincere Academy... >> dist\win-app\start.bat
echo electron . >> dist\win-app\start.bat
echo pause >> dist\win-app\start.bat

echo.
echo ✓ Build completed successfully!
echo.
echo Installation files created in: dist\win-app\
echo.
echo To run the application:
echo 1. Navigate to dist\win-app\
echo 2. Double-click start.bat
echo.
echo For distribution, zip the win-app folder and share with users.
