# 🏆 Natus Vincere Academy - Guia de Configuração da Base de Dados Online

## 📋 Índice
1. [Visão Geral](#visão-geral)
2. [Pré-requisitos](#pré-requisitos)
3. [Opção 1: Neon Database (Recomendado)](#opção-1-neon-database-recomendado)
4. [Opção 2: Supabase](#opção-2-supabase)
5. [Opção 3: Railway](#opção-3-railway)
6. [Opção 4: Render PostgreSQL](#opção-4-render-postgresql)
7. [Configuração no Sistema](#configuração-no-sistema)
8. [Teste de Conexão](#teste-de-conexão)
9. [Resolução de Problemas](#resolução-de-problemas)
10. [Segurança e Melhores Práticas](#segurança-e-melhores-práticas)

---

## 🎯 Visão Geral

O Natus Vincere Academy utiliza PostgreSQL como base de dados principal. Este guia apresenta várias opções gratuitas e pagas para hospedar sua base de dados online, permitindo que múltiplas instalações (web, desktop, mobile) compartilhem os mesmos dados.

### 🔧 Funcionalidades Suportadas
- Gestão completa de atletas e equipes
- Registros médicos e wellness
- Avaliações de treinos e jogos
- Sistema financeiro
- Relatórios e análises
- Sincronização entre plataformas

---

## ✅ Pré-requisitos

Antes de começar, certifique-se de ter:
- [ ] Acesso à internet estável
- [ ] Email válido para criar contas
- [ ] Instalador do Natus Vincere Academy para Windows 11
- [ ] Conhecimento básico de URLs e configuração

---

## 🌟 Opção 1: Neon Database (Recomendado)

**Vantagens:** Grátis até 0.5GB, PostgreSQL moderno, fácil configuração
**Desvantagens:** Limite de armazenamento no plano gratuito

### Passo a Passo:

#### 1. Criar Conta
1. Acesse [neon.tech](https://neon.tech)
2. Clique em "Sign Up"
3. Use sua conta Google, GitHub ou email
4. Confirme seu email se necessário

#### 2. Criar Base de Dados
1. No dashboard, clique em "New Project"
2. Configure:
   - **Nome do Projeto:** `natus-vincere-academy`
   - **Região:** Escolha a mais próxima (ex: Frankfurt, EU para Brasil)
   - **PostgreSQL Version:** 15 (recomendado)
3. Clique em "Create Project"

#### 3. Obter String de Conexão
1. Na página do projeto, vá para "Dashboard"
2. Em "Connection Details", clique em "Show"
3. Copie a **Connection String** que será similar a:
   ```
   postgres://username:password@ep-xxx.neon.tech/dbname?sslmode=require
   ```

#### 4. Configurar Esquema
1. No painel Neon, vá para "SQL Editor"
2. Execute o seguinte script para criar as tabelas:

```sql
-- Criação das tabelas principais
CREATE TABLE IF NOT EXISTS sessions (
    sid VARCHAR PRIMARY KEY,
    sess JSONB NOT NULL,
    expire TIMESTAMP NOT NULL
);

CREATE INDEX IF NOT EXISTS IDX_session_expire ON sessions(expire);

CREATE TABLE IF NOT EXISTS users (
    id VARCHAR PRIMARY KEY,
    email VARCHAR UNIQUE,
    first_name VARCHAR,
    last_name VARCHAR,
    profile_image_url VARCHAR,
    role VARCHAR DEFAULT 'atleta',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS system_config (
    id SERIAL PRIMARY KEY,
    key VARCHAR UNIQUE NOT NULL,
    value JSONB,
    description TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Inserir configurações padrão
INSERT INTO system_config (key, value, description) VALUES
('club_name', '"Natus Vincere Academy"', 'Nome do clube'),
('club_logo', '""', 'Logo do clube'),
('language', '"pt-BR"', 'Idioma padrão'),
('timezone', '"America/Sao_Paulo"', 'Fuso horário')
ON CONFLICT (key) DO NOTHING;
```

---

## 🎨 Opção 2: Supabase

**Vantagens:** 500MB grátis, interface amigável, recursos extras
**Desvantagens:** Mais complexo para iniciantes

### Passo a Passo:

#### 1. Criar Conta
1. Acesse [supabase.com](https://supabase.com)
2. Clique em "Start your project"
3. Faça login com GitHub ou email

#### 2. Criar Projeto
1. Clique em "New Project"
2. Configure:
   - **Organization:** Sua organização
   - **Name:** `natus-vincere-academy`
   - **Database Password:** Crie uma senha forte (anote!)
   - **Region:** South America (São Paulo)
3. Clique em "Create new project"

#### 3. Obter Configurações
1. Vá para "Settings" > "Database"
2. Em "Connection parameters", anote:
   - **Host:** db.xxx.supabase.co
   - **Database name:** postgres
   - **Port:** 5432
   - **User:** postgres
   - **Password:** [sua senha]

4. A string de conexão será:
   ```
   postgres://postgres:[password]@db.xxx.supabase.co:5432/postgres
   ```

---

## 🚂 Opção 3: Railway

**Vantagens:** $5 de crédito grátis, muito simples
**Desvantagens:** Requer cartão de crédito após teste

### Passo a Passo:

#### 1. Criar Conta
1. Acesse [railway.app](https://railway.app)
2. Clique em "Login" e use GitHub

#### 2. Criar Projeto
1. Clique em "New Project"
2. Selecione "Provision PostgreSQL"
3. Aguarde a criação (1-2 minutos)

#### 3. Obter String de Conexão
1. Clique na base de dados criada
2. Vá para "Connect"
3. Copie a "PostgreSQL Connection URL"

---

## 🎭 Opção 4: Render PostgreSQL

**Vantagens:** Plano gratuito permanente
**Desvantagens:** Limitações no plano gratuito

### Passo a Passo:

#### 1. Criar Conta
1. Acesse [render.com](https://render.com)
2. Clique em "Get Started" e use GitHub/email

#### 2. Criar Base de Dados
1. No dashboard, clique em "New +"
2. Selecione "PostgreSQL"
3. Configure:
   - **Name:** `natus-vincere-academy`
   - **Database:** `natusvincere`
   - **User:** `admin`
   - **Plan:** Free
4. Clique em "Create Database"

#### 3. Obter Informações
1. Na página da base de dados, encontre:
   - **External Database URL**
   - **Internal Database URL** (use a externa)

---

## ⚙️ Configuração no Sistema

### No Desktop (Windows 11):

#### 1. Abrir Aplicação
1. Execute "Natus Vincere Academy"
2. Faça login (se for a primeira vez, será criado automaticamente)

#### 2. Acessar Configurações
1. Clique no menu "Arquivo" > "Configurações"
2. Ou pressione `Ctrl+,`

#### 3. Configurar Base de Dados
1. Vá para a aba "Sistema"
2. Em "Configuração da Base de Dados":
   - **Tipo:** PostgreSQL Online
   - **URL da Conexão:** Cole sua string de conexão
   - **Teste de Conexão:** Clique para verificar

#### 4. Aplicar Migrações
1. Clique em "Aplicar Migrações"
2. Aguarde a criação das tabelas
3. Reinicie a aplicação

### Na Web:

#### 1. Variáveis de Ambiente
Se estiver hospedando na web, configure:
```bash
DATABASE_URL=sua_string_de_conexao_aqui
```

#### 2. Deploy
1. Faça push das suas alterações
2. Configure a variável DATABASE_URL no seu provedor
3. A aplicação detectará automaticamente

---

## 🧪 Teste de Conexão

### Verificações Essenciais:

#### 1. Teste Básico
```sql
SELECT version();
```
Deve retornar a versão do PostgreSQL.

#### 2. Teste de Tabelas
```sql
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public';
```
Deve listar todas as tabelas criadas.

#### 3. Teste de Usuário
```sql
SELECT * FROM users LIMIT 1;
```
Deve mostrar dados de usuário (se existir).

### No Sistema:
1. Vá para "Configurações" > "Sistema"
2. Clique em "Testar Conexão"
3. ✅ Verde = Sucesso
4. ❌ Vermelho = Erro (verifique logs)

---

## 🚨 Resolução de Problemas

### Erro: "Connection refused"
**Causa:** URL incorreta ou servidor indisponível
**Solução:**
1. Verifique se a URL está correta
2. Teste a conexão no navegador web do provedor
3. Verifique se o servidor está ativo

### Erro: "Authentication failed"
**Causa:** Credenciais incorretas
**Solução:**
1. Verifique usuário e senha
2. Regenere a senha se necessário
3. Confirme que copiou a string completa

### Erro: "SSL required"
**Causa:** Conexão não segura
**Solução:**
1. Adicione `?sslmode=require` na URL
2. Ou configure SSL no provedor

### Erro: "Database does not exist"
**Causa:** Base de dados não criada
**Solução:**
1. Confirme que a base existe no provedor
2. Execute as migrações novamente
3. Verifique o nome da base de dados

### Aplicação Lenta
**Causa:** Servidor distante ou sobrecarregado
**Solução:**
1. Escolha região mais próxima
2. Upgrade para plano pago
3. Otimize consultas

---

## 🔒 Segurança e Melhores Práticas

### 🛡️ Proteção de Dados

#### 1. Backups Automáticos
- **Neon:** Backup automático incluído
- **Supabase:** Backup diário no plano gratuito
- **Railway:** Configure backups manuais
- **Render:** Backup manual recomendado

#### 2. Controle de Acesso
```sql
-- Criar usuário apenas para leitura (opcional)
CREATE USER readonly_user WITH PASSWORD 'senha_forte';
GRANT CONNECT ON DATABASE natusvincere TO readonly_user;
GRANT USAGE ON SCHEMA public TO readonly_user;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO readonly_user;
```

#### 3. Monitoramento
- Configure alertas de uso no provedor
- Monitore conexões ativas
- Verifique logs regulamente

### 🔐 URLs Seguras
- Nunca compartilhe URLs de conexão publicamente
- Use variáveis de ambiente em produção
- Regenere senhas periodicamente

### 📊 Otimização
```sql
-- Criar índices importantes
CREATE INDEX IF NOT EXISTS idx_athletes_team ON athletes(team_id);
CREATE INDEX IF NOT EXISTS idx_training_date ON training_sessions(date);
CREATE INDEX IF NOT EXISTS idx_games_date ON games(date);
```

---

## 📞 Suporte

### Documentação Oficial dos Provedores:
- **Neon:** [docs.neon.tech](https://docs.neon.tech)
- **Supabase:** [supabase.com/docs](https://supabase.com/docs)
- **Railway:** [docs.railway.app](https://docs.railway.app)
- **Render:** [render.com/docs](https://render.com/docs)

### Suporte do Sistema:
- Email: suporte@natusvincere.academy
- Discord: [Link do servidor]
- GitHub Issues: [Link do repositório]

---

## ✅ Checklist Final

- [ ] Conta criada no provedor escolhido
- [ ] Base de dados PostgreSQL configurada
- [ ] String de conexão obtida e testada
- [ ] Tabelas criadas via migração
- [ ] Sistema conectado e funcionando
- [ ] Backup configurado
- [ ] Usuários criados e testados
- [ ] Performance verificada

---

**🎉 Parabéns! Sua base de dados online está configurada e pronta para uso.**

*Última atualização: Janeiro 2025 | Versão: 1.0*