# 🏆 Natus Vincere Academy - Instalador Windows 11 (Beta)

## 📦 Pacote de Instalação

### O que está incluído:
- **Instalador Principal:** `Natus Vincere Academy-Setup-1.0.0-Windows11.exe`
- **Versão Portátil:** `Natus Vincere Academy-Portable-1.0.0-Windows11.exe`
- **Guia de Base de Dados:** `DATABASE_SETUP.md`
- **Documentação:** Este arquivo

---

## ⚡ Instalação Rápida

### 1. Download e Execução
1. Baixe o arquivo `Natus Vincere Academy-Setup-1.0.0-Windows11.exe`
2. Clique com botão direito → "Executar como administrador"
3. Siga o assistente de instalação
4. O programa será instalado automaticamente

### 2. Configuração Inicial
1. Abra "Natus Vincere Academy" 
2. Será criado automaticamente um usuário administrador
3. Configure a base de dados online (ver próxima seção)

---

## 🗄️ Configuração da Base de Dados Online

### Opção Recomendada: Neon Database (Gratuito)

#### Passo 1: Criar Conta
1. Acesse: https://neon.tech
2. Clique em "Sign Up"
3. Use email ou conta Google/GitHub

#### Passo 2: Criar Projeto
1. Nome: `natus-vincere-academy`
2. Região: Mais próxima (Frankfurt-EU para Brasil)
3. Clique em "Create Project"

#### Passo 3: Obter URL de Conexão
1. No dashboard, vá para "Connection Details"
2. Copie a "Connection String"
3. Exemplo: `postgres://user:pass@host.neon.tech/dbname?sslmode=require`

#### Passo 4: Configurar no Sistema
1. Abra Natus Vincere Academy
2. Menu "Arquivo" → "Configurações"
3. Aba "Sistema" → "Base de Dados"
4. Cole a URL de conexão
5. Clique "Testar Conexão"
6. Se verde, clique "Aplicar Migrações"
7. Reinicie o programa

---

## 🖥️ Requisitos do Sistema

### Mínimo:
- **OS:** Windows 11 (Build 22000+)
- **RAM:** 4GB
- **Espaço:** 500MB livres
- **Internet:** Conexão estável para base de dados

### Recomendado:
- **OS:** Windows 11 22H2 ou superior
- **RAM:** 8GB ou mais
- **Espaço:** 1GB livres
- **Internet:** Banda larga

---

## 🔧 Funcionalidades

### ✅ Implementado nesta versão beta:
- Sistema completo de autenticação e usuários
- Gestão de atletas e equipes
- Registros médicos e wellness
- Sistema de treinos e avaliações
- Jogos e torneios
- Relatórios e análises
- Sistema financeiro
- Configurações avançadas
- Sincronização com base de dados online

### 🚧 Limitações conhecidas:
- Primeira versão beta, podem ocorrer bugs
- Função de backup automático em desenvolvimento
- Relatórios PDF em implementação
- Sincronização offline limitada

---

## 📱 Versões Disponíveis

### Desktop (Esta versão)
- **Plataforma:** Windows 11
- **Tipo:** Aplicação nativa
- **Instalação:** Automática com assistente
- **Performance:** Excelente

### Web (Disponível)
- **Acesso:** Via navegador
- **URL:** Configure sua própria instância
- **Compatibilidade:** Todos os navegadores modernos

### Mobile (Em desenvolvimento)
- **Android:** Versão beta disponível em breve
- **iOS:** Planejado para 2025

---

## 🛠️ Resolução de Problemas

### Erro na Instalação

#### "Windows protegeu seu PC"
1. Clique em "Mais informações"
2. Clique em "Executar assim mesmo"
3. O instalador é seguro, mas não assinado digitalmente ainda

#### "Não é possível instalar"
1. Execute como administrador
2. Verifique se Windows 11 está atualizado
3. Desative temporariamente o antivírus

### Problemas de Conexão

#### "Erro ao conectar com base de dados"
1. Verifique sua conexão de internet
2. Confirme se a URL está correta
3. Teste a URL no navegador do provedor
4. Verifique se o servidor está ativo

#### "Autenticação falhou"
1. Verifique usuário e senha na URL
2. Regenere credenciais no provedor
3. Confirme que copiou a string completa

### Performance

#### Aplicação lenta
1. Feche outros programas pesados
2. Verifique conexão de internet
3. Considere servidor de base de dados mais próximo
4. Upgrade para plano pago do provedor

#### Alto uso de memória
1. Reinicie a aplicação
2. Verifique se há vazamentos de memória
3. Feche abas desnecessárias no navegador integrado

---

## 🔄 Atualizações

### Automáticas
O sistema verifica atualizações automaticamente:
1. Notificação aparece quando disponível
2. Download automático em segundo plano
3. Instalação após confirmação do usuário

### Manuais
Para forçar verificação:
1. Menu "Ajuda" → "Verificar Atualizações"
2. Ou baixe nova versão do site oficial

---

## 💾 Backup e Restauração

### Dados de Usuário
Os dados ficam na base de dados online e são automaticamente preservados.

### Configurações Locais
Localização: `%APPDATA%\natus-vincere-academy\`
- Preferências da interface
- URLs de conexão
- Configurações de sincronização

### Backup Manual
1. Acesse configurações do provedor da base de dados
2. Execute backup manual
3. Download do arquivo de backup

---

## 🏥 Suporte Técnico

### Autoajuda
1. Consulte este guia
2. Verifique `DATABASE_SETUP.md`
3. Teste diferentes configurações

### Suporte Direto
- **Email:** suporte@natusvincere.academy
- **Horário:** Segunda a Sexta, 9h-18h BRT
- **Resposta:** Até 24 horas em dias úteis

### Comunidade
- **GitHub Issues:** Para bugs e sugestões
- **Discord:** Chat em tempo real com outros usuários
- **Documentação:** Wiki online sempre atualizada

---

## 📋 Checklist de Instalação

### Antes da Instalação:
- [ ] Windows 11 instalado e atualizado
- [ ] 500MB de espaço livre
- [ ] Conexão com internet estável
- [ ] Permissões de administrador

### Durante a Instalação:
- [ ] Executar como administrador
- [ ] Seguir assistente completo
- [ ] Permitir criação de atalhos
- [ ] Configurar firewall se solicitado

### Após a Instalação:
- [ ] Abrir aplicação
- [ ] Fazer login inicial
- [ ] Configurar base de dados online
- [ ] Testar conexão
- [ ] Aplicar migrações
- [ ] Criar primeiro usuário/atleta
- [ ] Verificar todas as funcionalidades

### Configuração da Base de Dados:
- [ ] Conta criada no provedor
- [ ] Projeto/base criada
- [ ] URL de conexão obtida
- [ ] Conexão testada no sistema
- [ ] Migrações aplicadas com sucesso
- [ ] Dados de teste criados

---

## 🎯 Próximos Passos

### Após Instalação Bem-sucedida:
1. **Configurar Usuários:** Crie contas para comissão técnica
2. **Adicionar Atletas:** Cadastre jogadores e dados básicos
3. **Criar Equipes:** Organize atletas em times
4. **Planejar Treinos:** Configure sessões e avaliações
5. **Configurar Torneios:** Adicione competições e jogos

### Treinamento da Equipe:
1. **Administradores:** Acesso completo ao sistema
2. **Coordenadores:** Gestão de atletas e treinos
3. **Comissão Técnica:** Avaliações e relatórios
4. **Médicos:** Registros médicos e wellness
5. **Atletas:** Visualização de dados pessoais

---

## 📊 Recursos Avançados

### Relatórios Disponíveis:
- Performance individual dos atletas
- Análises de equipe
- Progressão ao longo do tempo
- Relatórios médicos
- Análises financeiras

### Integrações:
- Exportação para Excel/CSV
- Impressão de relatórios
- Backup automático
- Sincronização multi-plataforma

### Personalização:
- Temas da interface
- Configurações de notificação
- Personalização de campos
- Logos e identidade visual

---

**🚀 Bem-vindo ao Natus Vincere Academy! Sua jornada para uma gestão profissional de academia de futebol começa agora.**

*Versão Beta 1.0.0 | Janeiro 2025 | Windows 11 Exclusive*